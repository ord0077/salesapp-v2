@component('mail::message')


Change done by CBC user.

Thanks,<br>
{{ config('app.name') }}
@endcomponent
